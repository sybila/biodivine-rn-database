import os
from collections import defaultdict
import csv


def read_pathway(file, organism):
    interactions = []
    file = open(file, 'r')
    for line in file:
        line = line.split()
        if organism == "Mouse":
            line[0] = line[0].capitalize()
            line[2] = line[2].capitalize()
        interactions.append((line[0], line[2], 'PathwayCommons', '-', '-', '-', '-', '-', '-', '-', '-'))
    return interactions


def read_enrichr(file):
    interactions = []
    file = open(file, 'r')
    for line in file:
        line = line.split()
        first_column = line[0].split('_')
        for i in range(1, len(line)):
            interactions.append((first_column[0], line[i], 'Enrichr', '-', '-', '-', '-', '-', '-', '-', '-'))
    return interactions


def read_grndb(file_path, organism, data_type):
    interactions = []
    file = open(file_path, 'r')
    if organism == "Human":
        conditions = file_path.split('/')[1].replace('-regulons.txt', '')
    else:
        conditions = file_path.split('/')[1].replace('whole_', '').replace('-regulons.txt', '')
    for line in file:
        line = line.split()
        if line[4] == 'High' or line[4] == 'Low':
            line.append(line[4])
            line[4] = '-'
        interactions.append((line[0], line[1], 'Grndb', organism,
                             data_type, '-', conditions + ": " + line[2],
                             conditions + ": " + line[3], conditions + ": " + line[4], conditions + ": " + line[5],
                             conditions))
    return interactions


def read_trrust(file, organism):
    interactions = []
    file = open(file, 'r')
    for line in file:
        line = line.split()
        interactions.append((line[0], line[1], 'Trrust', organism, '-', line[2], '-', '-', '-', '-', '-'))
    return interactions


def read_regnet(file, organism):
    interactions = []
    file = open(file, 'r')
    for line in file:
        line = line.split()
        interactions.append((line[0], line[2], 'RegNetwork', organism, '-', '-', '-', '-', '-', '-', '-'))
    return interactions


def read_all_in_folder_grndb(folder, organism, data_type):
    interactions = []
    files = os.listdir(folder)
    for file in files:
        interactions.extend(read_grndb(folder + '/' + file, organism, data_type))
    return interactions


def merge_lists(lists):
    merged_list = []
    for small_list in lists:
        merged_list.extend(small_list)
    return merged_list


def merge_all_columns_lists_csv(list_of_lists, filename):
    final_file = open(filename, 'w', newline='')
    csv_writer = csv.writer(final_file, delimiter=',')

    merged_list = [item for small_list in list_of_lists for item in small_list]
    all_columns_dict = defaultdict(lambda: [[] for _ in range(9)])
    merged_list.sort(key=lambda x: (x[0], x[1]))

    for row in merged_list:
        key = tuple(row[:2])
        values = row[2:]

        for i, val in enumerate(values):
            if val != '-':
                all_columns_dict[key][i].append(val)

    csv_writer.writerow(["Regulator", "Regulated gene", "Sources", "Organism",
                         "Data type", "Mode of regulation", "Best motif",
                         "NES", "Genie3Weight", "Confidence", "Location"])

    for key, lists_values in all_columns_dict.items():
        values_with_dashes = [','.join(map(str, set(l))) if l else '-' for l in lists_values]
        csv_writer.writerow([key[0], key[1]] + values_with_dashes)

    final_file.close()
    return final_file


if __name__ == '__main__':
    interactions_try = read_all_in_folder_grndb('grndb_try', 'Human', 'Bulk')
    interactions_1 = read_pathway('homo-sapiens-9606.sif', 'Human')
    interactions_human = read_pathway('homo-sapiens-9606.sif', 'Human')
    interactions_grndb = read_all_in_folder_grndb('grndb_human_bulk', 'Human', 'Bulk')
    interactions_grndb_final = merge_all_columns_lists_csv([interactions_grndb], 'interactions_try2.csv')
