from collections import defaultdict
import csv
from cli import read_synonyms, find_most_known_name, find_successors_interactions,\
    find_predecessors_interactions, make_table_from_file, binary_search_table
from typing import List, Tuple, Optional, Dict


def return_tgs_for_tf(gene: str, is_human: bool, normalized: bool) -> Optional[List[Tuple[str, str]]]:
    """
    Input parameters:
    gene: string, symbol of gene for which user wants to find all target_genes
    is_human: boolean, True if organism is human, False if organism is mouse
    normalized: True if gene symbols should be normalized and False if same as in original databases
    Output:
    Returns list of tuples of target gene and sources of information about this interaction or None if
    there are no successors or the input is incorrect.
    """
    if is_human:
        synonyms = read_synonyms('Homo_sapiens.gene_info')
        successors = find_successors_interactions('interactions_human.csv')
        gene = find_most_known_name(synonyms, gene, "Human")
        organism = "Human"
    else:
        synonyms = read_synonyms('Homo_sapiens.gene_info')
        successors = find_successors_interactions('interactions_mouse.csv')
        gene = find_most_known_name(synonyms, gene, "Mouse")
        organism = "Mouse"
    if not normalized:
        if gene not in successors.keys():
            return None
        else:
            return successors[gene]
    return normalized_finder(gene, synonyms, organism, successors)


def return_tfs_for_tg(gene: str, is_human: bool, normalized: bool) -> Optional[List[Tuple[str, str]]]:
    """
    Input parameters:
    gene: string, symbol of gene for which user wants to find all transcription factors
    is_human: boolean, True if organism is human, False if organism is mouse
    normalized: True if gene symbols should be normalized and False if same as in original databases
    Output:
    Returns tuples of transcription factor and sources of information about this interaction or None if there
    are no predecessors or the input is incorrect..
    """
    if is_human:
        synonyms = read_synonyms('Homo_sapiens.gene_info')
        predecessors = find_predecessors_interactions('interactions_human.csv')
        gene = find_most_known_name(synonyms, gene, "Human")
        organism = "Human"
    else:
        synonyms = read_synonyms('Mus_musculus.gene_info')
        predecessors = find_predecessors_interactions('interactions_mouse.csv')
        gene = find_most_known_name(synonyms, gene, "Mouse")
        organism = "Mouse"
    if not normalized:
        if gene not in predecessors.keys():
            return None
        else:
            return predecessors[gene]
    return normalized_finder(gene, synonyms, organism, predecessors)


def normalized_finder(gene: str, synonyms: Dict[str, List[str]], organism: str,
                      successors_or_predecessors: Dict[str, List[Tuple[str, str]]]) -> Optional[List[Tuple[str, str]]]:
    returned_genes = []
    for key, values in successors_or_predecessors.items():
        if key.lower() == gene.lower():
            for tf_or_tg in values:
                returned_genes.append((find_most_known_name(synonyms, tf_or_tg[0], organism), tf_or_tg[1]))
    if len(returned_genes) > 0:
        return returned_genes
    return None


def return_info_about_two_genes(transcription_factor: str, target_gene: str, is_human: bool) -> Optional[List[str]]:
    """
    Input parameters:
    transcription_factor: string, transcription factor in the interaction
    target_gene: string, target gene in the interaction
    is_human: boolean, True if organism is human, False if organism is mouse
    Output:
    returns list of information about interaction between this transcription factor and target gene or None if there
    is no interactions or one of the arguments is incorrect.
    """
    if is_human:
        synonyms = read_synonyms('Homo_sapiens.gene_info')
        organism = "Human"
        table = make_table_from_file('interactions_human.csv')
        tf = find_most_known_name(synonyms, transcription_factor, "Human")
        tg = find_most_known_name(synonyms, target_gene, "Human")
    else:
        synonyms = read_synonyms('Mus_musculus.gene_info')
        organism = "Mouse"
        table = make_table_from_file('interactions_mouse.csv')
        tf = find_most_known_name(synonyms, transcription_factor, "Mouse")
        tg = find_most_known_name(synonyms, target_gene, "Mouse")
    if tf is not None and tg is not None:
        for tf_synonym in [tf, *synonyms[tf]]:
            for tg_synonym in [tg, *synonyms[tg]]:
                return binary_search_table(tf_synonym, tg_synonym, table, organism)
    return None


def return_info_about_group(list_of_genes: List[str], is_human: bool) -> \
        Optional[List[Tuple[str, str, str]]]:
    """
    Input parameters:
    list_of_genes: List[string], list of symbols for genes in interactions
    is_human: boolean, True if organism is human, False if organism is mouse
    Output:
    Returns list of tuples, which consist of transcription factor, target gene among given genes and sources of these
    interactions or None if there are no interaction,
    just 0 or 1 genes in list_of_genes or incorrect genes in list_of_genes.
    """
    if len(list_of_genes) < 2:
        return None
    if is_human:
        synonyms = read_synonyms('Homo_sapiens.gene_info')
        organism = "Human"
        table = make_table_from_file('interactions_human.csv')
    else:
        synonyms = read_synonyms('Mus_musculus.gene_info')
        organism = "Mouse"
        table = make_table_from_file('interactions_mouse.csv')
    normalized_genes = []
    for gene in list_of_genes:
        gene = find_most_known_name(synonyms, gene, organism)
        normalized_genes.append(gene)
    all_pairs = []
    for tf in normalized_genes:
        for tg in normalized_genes:
            if tf is not None and tg is not None:
                searched_interaction = binary_search_table(tf, tg, table, organism)
                if searched_interaction is not None:
                    all_pairs.append((searched_interaction[0], searched_interaction[1],
                                      searched_interaction[2]))

    if all_pairs is not None:
        return all_pairs
    return None


def return_info_about_gene(gene: str, is_human: bool) -> Optional[List[str]]:
    """
    Input parameters:
    gene: string, symbol of gene for which user wants to find info
    is_human: boolean, True if organism is human, False if organism is mouse
    Output:
    Returns list of information about gene in format [TaxID, GeneID, Symbol, Synonyms, Description, Type of gene,
    Symbol from nomenclature authority, Full name from nomenclature authority] or None if gene is not among
    most known symbols
    """
    if is_human:
        synonyms = read_synonyms('Homo_sapiens.gene_info')
        gene_table = open('Homo_sapiens.gene_info', 'r')
        gene = find_most_known_name(synonyms, gene, "Human")
    else:
        synonyms = read_synonyms('Homo_sapiens.gene_info')
        gene_table = open('Mus_musculus.gene_info', 'r')
        gene = find_most_known_name(synonyms, gene, "Mouse")

    for line in gene_table:
        line_split = line.split()
        if line[2].lower() == gene.lower():
            return [line_split[0], line_split[1], line_split[2], line_split[4],
                    line_split[8], line_split[9], line_split[10], line_split[11]]
    return None


def return_possible_main_names_for_gene(gene: str, is_human: bool) -> List[str]:
    """
    Input parameters:
    gene: string, symbol of gene for which user wants to find all possible genes that can use this symbol
    is_human: boolean, True if organism is human, False if organism is mouse
    Output:
    Returns list of most known names of genes that can possibly use this symbol.
    """
    possible_genes = []
    if is_human:
        synonyms = read_synonyms('Homo_sapiens.gene_info')
    else:
        synonyms = read_synonyms('Mus_musculus.gene_info')
    for key, values in synonyms.items():
        if gene.lower() == key.lower():
            possible_genes.append(key)
        if gene.lower() in [v.lower() for v in values]:
            possible_genes.append(key)
    return possible_genes


if __name__ == '__main__':
    synonyms_1 = read_synonyms('Homo_sapiens.gene_info')
    synonyms_2 = read_synonyms('Mus_musculus.gene_info')
    all_genes_human = 'Homo_sapiens.gene_info'
    all_genes_mouse = 'Mus_musculus.gene_info'
    print(return_tgs_for_tf('A2M', True, True))
    print(return_tfs_for_tg('A2M', True, True))
    print(return_info_about_two_genes('A2M', 'APOD', True))
    print(return_info_about_group(['ABCF1', 'ABCF3', 'NAT10'], True))
    print(return_info_about_gene('A2M', True))
    print(return_possible_main_names_for_gene('A2M', True))
    # print(return_tgs_for_tf('NAT10', True, True))
    # print(return_tgs_for_tf('NAT10', True, False))
